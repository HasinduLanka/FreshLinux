<h1>Quarks Splash Darker</h1>

<h3>This splash is based on [Quarks Splash Dark](https://store.kde.org/p/1304256/) by ADHE</h3>

<h5>Install</h5>

```
kpackagetool5 -t Plasma/LookAndFeel -i <splash name>.tar.gz
```

<h5>Remove</h5>

```
kpackagetool5 -t Plasma/LookAndFeel -r <splash name>
```
